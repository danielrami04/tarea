
package com.examen_1.dao;

import com.examen_1.domain.Publicacion;
import org.springframework.data.repository.CrudRepository;


public interface PublicacionDao extends CrudRepository< Publicacion, Long>{
    
}
